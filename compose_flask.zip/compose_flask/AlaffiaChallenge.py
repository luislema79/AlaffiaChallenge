import requests
import json
from flask import Flask, jsonify, request, make_response
from flask_restful import Resource, Api
import csv

url = 'http://api.coingecko.com/api/v3/coins/{}/tickers'

app = Flask(__name__)
api = Api(app)
counter = 0

class Coins(Resource):
    def post(self):
        global counter
        response = {}
        counter += 1
        req = request.data.decode()
        header = request.headers['content-type']
        if header == 'application/json':            
            jdata = json.loads(req)
            print(jdata)
            for coin in jdata["coins"]:
                response["id"] = coin
                response["exchanges"] = []
                response["taskRun"] = counter
                req = requests.get(url.format(coin))
                if req.status_code == 429:
                    print(response)
                    return make_response(jsonify(response), 200)
                dic = req.json()
                if "error" not in dic.keys():                    
                    print(dic)
                    for item in dic["tickers"]:
                        response["exchanges"].append(item["market"]["identifier"])
                    print(response)
                    return make_response(jsonify(response), 200)
        else:
            for coin in req.splitlines()[1:]:
                response["id"] = coin
                response["exchanges"] = []
                response["taskRun"] = counter
                req = requests.get(url.format(coin))
                if req.status_code == 429:
                    print(response)
                    return make_response(jsonify(response), 200)
                print(req.status_code)
                dic = req.json()
                if "error" not in dic.keys():                   
                    print(dic)
                    for item in dic["tickers"]:
                        response["exchanges"].append(item["market"]["identifier"])
                    print(response)
                    return make_response(jsonify(response), 200)
            
            


api.add_resource(Coins, '/coins')

if __name__ == '__main__':
    app.run(port=5000, host='0.0.0.0')